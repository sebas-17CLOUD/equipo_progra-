/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import datos.Usuarios;
import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class IniciarDatosUsuarios {
    public static ArrayList<Usuarios> NuevosRegistros = new ArrayList<Usuarios>();
}
